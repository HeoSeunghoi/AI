from util import manhattanDistance
from game import Directions
import random
import util

from game import Agent

## Example Agent


class ReflexAgent(Agent):

  def Action(self, gameState):

    move_candidate = gameState.getLegalActions()

    scores = [self.reflex_agent_evaluationFunc(
        gameState, action) for action in move_candidate]
    bestScore = max(scores)
    Index = [index for index in range(
        len(scores)) if scores[index] == bestScore]
    get_index = random.choice(Index)

    return move_candidate[get_index]

  def reflex_agent_evaluationFunc(self, currentGameState, action):

    successorGameState = currentGameState.generatePacmanSuccessor(action)
    newPos = successorGameState.getPacmanPosition()
    oldFood = currentGameState.getFood()
    newGhostStates = successorGameState.getGhostStates()
    newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

    return successorGameState.getScore()


def scoreEvalFunc(currentGameState):

  return currentGameState.getScore()


class AdversialSearchAgent(Agent):

  def __init__(self, getFunc='scoreEvalFunc', depth='2'):
    self.index = 0
    self.evaluationFunction = util.lookup(getFunc, globals())

    self.depth = int(depth)

######################################################################################


class MinimaxAgent(AdversialSearchAgent):
  """
    [문제 01] MiniMax의 Action을 구현하시오. (20점)
    (depth와 evaluation function은 위에서 정의한 self.depth and self.evaluationFunction을 사용할 것.)
  """
  def Action(self, gameState):
    ####################### Write Your Code Here ################################
    def check_end(state, depth): #함수 종료조건 확인
      return depth == self.depth or state.isWin() or state.isLose()
    def minmax(state, depth, cost, agentIndex): #Pacman은 max값을 선택하고 ghost는 min을 선택한다.
      if check_end(state, depth):
        return self.evaluationFunction(state)
      else:
        legalMoves = state.getLegalActions(agentIndex)
        for action in legalMoves:
          if agentIndex == 0: #pacman
            cost = max(cost, minmax(state.generateSuccessor(agentIndex, action), depth, float("inf"), agentIndex+1))
          elif agentIndex == state.getNumAgents()-1:
            cost = min(cost, minmax(state.generateSuccessor(agentIndex, action), depth+1, float("-inf"), 0))
          else: #ghost
            cost = min(cost, minmax(state.generateSuccessor(agentIndex, action), depth, float("inf"), agentIndex+1))
        return cost
    
    legalMoves = gameState.getLegalActions(0)
    move = Directions.STOP
    start_cost = float("inf")
    cost = float("-inf")
    for action in legalMoves:
      temp = minmax(gameState.generateSuccessor(0, action), 0, start_cost, 1)
      if temp > cost:
        cost = temp
        move = action
    return move


    #raise Exception("Not implemented yet")

    ############################################################################




class AlphaBetaAgent(AdversialSearchAgent):
  """
    [문제 02] AlphaBeta의 Action을 구현하시오. (25점)
    (depth와 evaluation function은 위에서 정의한 self.depth and self.evaluationFunction을 사용할 것.)
  """
  def Action(self, gameState):
    ####################### Write Your Code Here ################################
    def check_end(state, depth): #함수 종료조건 확인
      return depth == self.depth or state.isWin() or state.isLose()
    def alphabeta(state, depth, alpha, beta, cost, agentIndex):
      if check_end(state, depth):
        return self.evaluationFunction(state)
      else:
        legalMoves = state.getLegalActions(agentIndex)
        for action in legalMoves:
          if agentIndex == 0:
            cost = max(cost, alphabeta(state.generateSuccessor(agentIndex, action), depth, alpha, beta, float("inf"), agentIndex+1))
            if cost > beta:
              return cost
            alpha = max(cost, alpha)
          elif agentIndex == state.getNumAgents()-1:
            cost = min(cost, alphabeta(state.generateSuccessor(agentIndex, action), depth+1, alpha, beta, float("-inf"), 0))
            if cost < alpha:
              return cost
            beta = min(cost, beta)
          else:
            cost = min(cost, alphabeta(state.generateSuccessor(agentIndex, action), depth, alpha, beta, float("inf"), agentIndex+1))
            if cost < alpha:
              return cost
            beta = min(cost, beta)
        return cost
    legalMoves = gameState.getLegalActions(0)
    move = Directions.STOP
    alpha = float("-inf")
    cost = float("-inf")
    for action in legalMoves:
      temp = alphabeta(gameState.generateSuccessor(0, action), 0, float("-inf"), float("inf"), float("inf"), 1)
      if temp > cost:
        cost = temp
        move = action
      alpha = max(cost, alpha)
    return move

    #raise Exception("Not implemented yet")

    ############################################################################



class ExpectimaxAgent(AdversialSearchAgent):
  """
    [문제 03] Expectimax의 Action을 구현하시오. (25점)
    (depth와 evaluation function은 위에서 정의한 self.depth and self.evaluationFunction을 사용할 것.)
  """
  def Action(self, gameState):
    ####################### Write Your Code Here ################################

    def check_end(state, depth): #함수 종료조건 확인
      return depth == self.depth or state.isWin() or state.isLose()

    def expecti(state, depth, cost, agentIndex):
      if check_end(state, depth):
        return self.evaluationFunction(state)
      
      else:
        legalMoves = state.getLegalActions(agentIndex)
        
        for action in legalMoves:
          if agentIndex == 0:
            cost = max(cost, expecti(state.generateSuccessor(agentIndex, action), depth+1, 0, agentIndex+1))
          elif agentIndex == state.getNumAgents()-1:
            cost += expecti(state.generateSuccessor(agentIndex, action), depth, float("-inf"), 0)
          else:
            cost += expecti(state.generateSuccessor(agentIndex, action), depth+1, 0, agentIndex+1)
        if agentIndex == 0:
          return cost
        else:
          return cost/len(legalMoves)

    legalMoves = gameState.getLegalActions(0)
    move = Directions.STOP
    cost = float("-inf")
    for action in legalMoves:
      temp = expecti(gameState.generateSuccessor(0, action), 0, 0, 1)
      if temp > cost:
        cost = temp
        move = action
    return move

    #raise Exception("Not implemented yet")

    ############################################################################
