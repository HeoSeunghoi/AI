###### Write Your Library Here ###########

from maze import Maze
import math
import copy
from queue import PriorityQueue

#########################################


def search(maze, func):
    return {
        "bfs": bfs,
        "astar": astar,
        "astar_four_circles": astar_four_circles,
        "astar_many_circles": astar_many_circles
    }.get(func)(maze)


# -------------------- Stage 01: One circle - BFS Algorithm ------------------------ #

def bfs(maze):
    """
    [문제 01] 제시된 stage1의 맵 세가지를 BFS Algorithm을 통해 최단 경로를 return하시오.(20점)
    """
    start_point=maze.startPoint()

    path=[]

    ####################### Write Your Code Here ################################
    flag = 0
    current_point = start_point
    head_node = Node(None, start_point)
    current_node = head_node
    
    queue = []
    hist = []
    
    while True:
        hist.append(current_node)
        current_row = current_node.location[0]
        current_col = current_node.location[1]
        
        neighbors = maze.neighborPoints(current_row, current_col)
        count = int(len(hist))
        
        
        for i in range(count):#neighbors정리(방문한 기록이 있는 neighbor는 삭제)
            if hist[i].location in neighbors:
                index = neighbors.index(hist[i].location)
                del neighbors[index]
        
                    
        for i in neighbors:#object인 neighbor인지 확인
            if maze.isObjective(i[0],i[1]):
                last_node = Node(current_node,i)
                mov = last_node
                while True:#
                    if mov == head_node:
                        break
                    else:
                        path.append(mov.location)
                        mov = mov.parent
                break
        if len(path) != 0:#path에 경로가 역순으로 저장된 경우
            path.append(mov.location)
            break
        
        for i in neighbors:
            queue.append(Node(current_node, i))
        
        if queue:
            current_node = queue[0]
            del queue[0]
            
        else:
            print("there is no onject point")
            break
                         
    if not queue:
        return 0
    path.reverse()
    return path

    ############################################################################



class Node:
    def __init__(self,parent,location):
        self.parent=parent
        self.location=location #현재 노드
        
        self.obj=[] #지금까지 방문한 end points
        self.path=[] #출발지부터 지금까지 경로

        # F = G+H
        self.f=0
        self.g=0
        self.h=0

    def __eq__(self, other):
        return self.location==other.location and str(self.obj)==str(other.obj)

    def __le__(self, other):
        return self.g+self.h<=other.g+other.h

    def __lt__(self, other):
        return self.g+self.h<other.g+other.h

    def __gt__(self, other):
        return self.g+self.h>other.g+other.h

    def __ge__(self, other):
        return self.g+self.h>=other.g+other.h


# -------------------- Stage 01: One circle - A* Algorithm ------------------------ #

def manhatten_dist(p1,p2):
    return abs(p1[0]-p2[0])+abs(p1[1]-p2[1])

def astar(maze):

    """
    [문제 02] 제시된 stage1의 맵 세가지를 A* Algorithm을 통해 최단경로를 return하시오.(20점)
    (Heuristic Function은 위에서 정의한 manhatten_dist function을 사용할 것.)
    """

    start_point=maze.startPoint()

    end_point=maze.circlePoints()[0]

    path=[]

    ####################### Write Your Code Here ################################

    open_set = []
    close_set = []
    flag = 0
    start_node = Node(None, start_point)
    current_node = start_node
    
    while True:
        close_set.append(current_node)
        
        neighbors = maze.neighborPoints(current_node.location[0], current_node.location[1])
                
        if end_point in neighbors:
            index = neighbors.index(end_point)
            temp = Node(current_node, neighbors[index])
            temp.g = current_node.g + 1
            temp.h = manhatten_dist(temp.location, end_point)
            temp.f = temp.f + temp.h
            
            while True:#path 구현
                if temp == start_node:
                    break
                else:
                    path.append(temp.location)
                    temp = temp.parent
            if len(path) != 0:
                path.append(start_node.location)
            break
            
        for i in neighbors:#neighbors node open에 저장
            temp = Node(current_node, i)
            temp.g = current_node.g + 1
            a = temp.location[0] - end_point[0]
            b = temp.location[1] - end_point[1]
            temp.h = math.sqrt((a * a) + (b * b))
            temp.f = temp.g + temp.h
            
            for j in close_set:
                if i == j.location:
                    flag = 1
                    break
            if flag == 1:
                flag = 0
                continue
                
            for j in open_set:
                if i == j.location and temp.f < j.f:
                    index = open_set.index(j)
                    open_set[index] = temp
                    break
                elif j == open_set[-1]:
                    open_set.append(temp)
                    break
            
            if not open_set:
                open_set.append(temp)
                
        next_node = open_set[0]
        for i in open_set:
            if next_node.f > i.f:
                next_node = i
        current_node = next_node
        index = open_set.index(next_node)
        del open_set[index]
    path.reverse()
    return path

    ############################################################################


# -------------------- Stage 02: Four circles - A* Algorithm  ------------------------ #

def route(maze, p1, p2):
    start_point = p1
    end_point = p2
    flag = 0
    path = []
    open_set = []
    close_set = []
    start_node = Node(None, start_point)
    current_node = start_node
    while True:
        close_set.append(current_node.location)
        
        neighbors = maze.neighborPoints(current_node.location[0], current_node.location[1])
                
        if end_point in neighbors:
            index = neighbors.index(end_point)
            temp = Node(current_node, neighbors[index])
            
            temp.g = current_node.g + 1
            temp.h = manhatten_dist(temp.location, end_point)
            temp.f = temp.f + temp.h
            
            while True:#path
                if temp == start_node:
                    break
                elif temp.location == end_point:
                    temp = temp.parent
                else:
                    path.append(temp.location)
                    temp = temp.parent
            
            path.reverse()
            return path
            
        for i in neighbors:#neighbors node open에 저장
            temp = Node(current_node, i)
            
            temp.g = current_node.g + 1
            temp.h = manhatten_dist(temp.location, end_point)
            temp.f = temp.g + temp.h
            
            if i in close_set:
                continue
            
            for j in open_set:
                if i == j.location and temp.f < j.f:
                    index = open_set.index(j)
                    open_set[index] = temp
                    break
                elif j == open_set[-1] and i != j.location:
                    open_set.append(temp)
                    break
            if not open_set:
                open_set.append(temp)
        next_node = open_set[0]
        for i in open_set:
            if next_node.f > i.f:
                next_node = i
                
        current_node = next_node
        index = open_set.index(next_node)
        del open_set[index]
        

def stage2_heuristic(current_location, objectives, edges):
    total_cost = 0
    visit = ()
    max_length = -1
    min_cost = -1
    if len(edges) == 0:
        return total_cost
    max_length = max(edges.values()) +1
    for i in edges.keys():
        if current_location in i:
            if min_cost == -1 or min_cost > edges[i]:
                min_cost = edges[i]
            edges[i] = max_length
    total_cost = min_cost
    
    while True:
        if len(set(visit)) == len(objectives) or len(objectives) == 1:
            return total_cost
        if len(visit) == 0:
            min_key = min(edges.keys(),key=(lambda x : edges[x]))
            min_cost = edges[min_key]
            edges[min_key] = max_length
            visit += min_key
            total_cost += min_cost
        else:    
            min_key = min(edges.keys(),key=(lambda x : edges[x]))
            min_cost = edges[min_key]
            edges[min_key] = max_length
            visit += min_key
            total_cost += min_cost
            
def astar_four_circles(maze):
    """
    [문제 03] 제시된 stage2의 맵 세가지를 A* Algorithm을 통해 최단 경로를 return하시오.(30점)
    (단 Heurstic Function은 위의 stage2_heuristic function을 직접 정의하여 사용해야 한다.)
    """

    start_point=maze.startPoint()
    end_points=maze.circlePoints()
    end_points.sort()

    path=[]
    edges={}
    dic={}
    ####################### Write Your Code Here ################################
    open_set = PriorityQueue()
    for i in range(len(end_points)):
        edges[(0,i+1)] = route(maze, start_point, end_points[i])
        
    for i in range(len(end_points) - 1):
        for j in range(i+1, len(end_points)):
            edges[(i+1,j+1)] = route(maze, end_points[i], end_points[j])
    
    ############### path list는 만들었고, 그 path list의 len으로 최단 거리 구하고,
    ############### 그 순서에 맞게 path를 연결시켜 주면 될 듯
    
    start_node = Node(None, start_point)
    current_node = start_node
    
    
    while True:
        for i in [x for x in end_points if x not in current_node.obj]:
            temp = Node(current_node, i)
            temp.obj = copy.deepcopy(current_node.obj)
            temp.obj.append(i)
            
            if current_node.location == start_node.location:
                current_location_num = 0
                i_location_num = end_points.index(i)+1
            else:
                current_location_num = end_points.index(current_node.location)+1
                i_location_num = end_points.index(i)+1
            
            if (current_location_num, i_location_num) in edges.keys():
                temp.path = copy.deepcopy(edges[(current_location_num, i_location_num)])
                temp.path.insert(0,current_node.location)
                
            elif (i_location_num, current_location_num) in edges.keys():
                temp.path = copy.deepcopy(edges[(i_location_num, current_location_num)][::-1])
                temp.path.insert(0, current_node.location)
            
            use_edges = {}
            for j in edges.keys():
                if 0 in j:
                    continue
                if end_points[j[0]-1] not in current_node.obj and end_points[j[1]-1] not in current_node.obj and j[0] < j[1]:
                    use_edges[j] = len(edges[j])+1
            
            temp.g = current_node.g + len(temp.path)
            temp.h = stage2_heuristic(i_location_num, [x for x in end_points if x not in temp.obj], use_edges)
            temp.f = temp.g + temp.h
            open_set.put(temp)
            
        if len(temp.obj) == 4:
            path.append(temp.obj[-1])
            while True:
                if temp == start_node:
                    break
                else:
                    path.extend(reversed(temp.path))
                    temp = temp.parent
            break
        
        current_node = open_set.get()
    path.reverse()
    return path

    ############################################################################



# -------------------- Stage 03: Many circles - A* Algorithm -------------------- #

def mst(objectives, edges):
    cost_sum=0
    ####################### Write Your Code Here ################################
    #목적지 list를 objectibes로 받고 node사이의 유클리드 거리를 edge로 받는다
    #연결된 노드는 하나의 노드로 본다.
    #prim 알고리즘 사용
    visit = () #방문한 목적지
    
    if len(edges) == 0:
        return cost_sum
    
    max_length = max(edges.values())
    edges = dict(sorted(edges.items(), key= lambda x : x[1]))
    while True:
        if len(set(visit)) == len(objectives):
            break
        for i in edges:
            if len(visit) == 0:
                min_cost = edges[i]
                edges[i] = max_length + 1
                break
            elif i[0] in visit or i[1] in visit:
                min_cost = edges[i]
                edges[i] = max_length + 1
                break
        visit += i #방문한 노드 tuple에 추가
        cost_sum += min_cost #cost를 sum cost에 추가
        
        
        #싸이클이 생기는 간선을 모두 제거
        for i in edges.keys():
            if i[0] in visit and i[1] in visit:
                edges[i] = max_length + 1
        
        edges = dict(sorted(edges.items(), key= lambda x : x[1]))
    
    return cost_sum

    ############################################################################


def stage3_heuristic(current_location, objectives, edges):
    total_cost = 0
    use_edges = {}
    if len(edges) == 0:
        return total_cost
    for i in edges.keys():
        if current_location in i:
            if total_cost == 0 or total_cost > edges[i]:
                total_cost = edges[i]
    if len(objectives) != 1:
        for i in edges.keys():
            if current_location not in i:
                use_edges[i] = edges[i]
        total_cost += mst(objectives, use_edges)
    
    return total_cost

def astar_many_circles(maze):
    """
    [문제 04] 제시된 stage3의 맵 세가지를 A* Algorithm을 통해 최단 경로를 return하시오.(30점)
    (단 Heurstic Function은 위의 stage3_heuristic function을 직접 정의하여 사용해야 하고, minimum spanning tree
    알고리즘을 활용한 heuristic function이어야 한다.)
    """

    start_point=maze.startPoint()
    end_points=maze.circlePoints()
    end_points.sort()

    path=[]

    ####################### Write Your Code Here ################################
    
    open_set = PriorityQueue()
    
    edges = {}
    
    for i in range(len(end_points)):
        edges[(0,i+1)] = route(maze, start_point, end_points[i])
        
    for i in range(len(end_points) - 1):
        for j in range(i+1, len(end_points)):
            edges[(i+1,j+1)] = route(maze, end_points[i], end_points[j])
    start_node = Node(None,start_point)
    current_node = start_node
    while True:
        #temp node를 만든다
        for i in [x for x in end_points if x not in current_node.obj]:
            temp = Node(current_node, i)
            
            temp.obj = copy.deepcopy(current_node.obj)
            temp.obj.append(i)
            #새로운 path를 찾았을 땐 dic에 두 좌표와 path를 저장해서 재탐색 방지**
            
            if current_node.location == start_node.location:
                current_location_num = 0
                i_location_num = end_points.index(i)+1
            else:
                current_location_num = end_points.index(current_node.location)+1
                i_location_num = end_points.index(i)+1
            
            use_edges = {}
            for j in edges.keys():
                if 0 in j:
                    continue
                elif end_points[j[0]-1] not in current_node.obj and end_points[j[1]-1] not in current_node.obj:
                    use_edges[j] = len(edges[j])+1
                
            if (current_location_num, i_location_num) in edges.keys():
                temp.path = copy.deepcopy(edges[(current_location_num, i_location_num)])
                temp.path.insert(0,current_node.location)
                
            elif (i_location_num, current_location_num) in edges.keys():
                temp.path = copy.deepcopy(edges[(i_location_num, current_location_num)][::-1])
                temp.path.insert(0, current_node.location)
            
            temp.g = current_node.g + len(temp.path)
            temp.h = stage3_heuristic(i_location_num, [x for x in end_points if x not in temp.obj], use_edges)
            temp.f = temp.g + temp.h
            
            open_set.put(temp)
        
        #모든 end points를 방문
        if len(temp.obj) == len(end_points):
            path.append(temp.obj[-1])
            while True:
                if temp == start_node:
                    break
                else:
                    path.extend(reversed(temp.path))
                    temp = temp.parent
            break
            #모든 노드를 방문했으면 path를 기록하고 종료
        current_node = open_set.get()
    
    path.reverse()
    return path


    ############################################################################